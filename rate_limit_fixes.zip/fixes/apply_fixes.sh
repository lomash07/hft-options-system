#!/bin/bash
# ──────────────────────────────────────────────
# Run this from INSIDE your project directory:
#   cd /workspaces/hft-options-system
#   bash apply_fixes.sh
# ──────────────────────────────────────────────

echo "🔧 Applying rate-limit fixes..."

# Backup originals
mkdir -p backups
cp data/broker_feed.py backups/broker_feed.py.bak 2>/dev/null
cp data/feature_store.py backups/feature_store.py.bak 2>/dev/null
cp data/market_regime.py backups/market_regime.py.bak 2>/dev/null
cp scanner/__init__.py backups/scanner_init.py.bak 2>/dev/null
echo "  ✅ Originals backed up to backups/"

# Copy fixed files
cp fixes/data/broker_feed.py data/broker_feed.py
cp fixes/data/feature_store.py data/feature_store.py
cp fixes/data/market_regime.py data/market_regime.py
cp fixes/scanner/__init__.py scanner/__init__.py
echo "  ✅ Fixed files applied"

echo ""
echo "🚀 Done! Now run:"
echo "   python main.py --scan-only"
